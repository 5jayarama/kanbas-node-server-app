import mongoose from "mongoose";
import schema from "./schema.js";
const model = mongoose.model("AnswerModel", schema);
export default model;